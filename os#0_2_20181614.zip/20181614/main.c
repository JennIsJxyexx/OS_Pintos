#include "main.h"

void* aux = 0;

char func_array[44][30] = {"bitmap_mark", "bitmap_all", "bitmap_any", "bitmap_contains", "bitmap_count", "bitmap_dump", "bitmap_expand", "bitmap_flip", "bitmap_none", "bitmap_reset", "bitmap_scan_and_flip", "bitmap_scan", "bitmap_set_all", "bitmap_set_multiple", "bitmap_set", "bitmap_size", "bitmap_test", "hash_insert", "hash_apply", "hash_delete", "hash_empty", "hash_size", "hash_clear", "hash_find", "hash_replace", "list_push_front", "list_push_back", "list_front", "list_back", "list_pop_back", "list_pop_front", "list_insert_ordered", "list_insert", "list_empty", "list_size", "list_max", "list_min", "list_remove", "list_reverse", "list_shuffle", "list_sort", "list_splice", "list_swap", "list_unique"};

int main() {
    bitmap_cnt = 0; hash_cnt = 0; list_cnt = 0;

    char *str = (char*)malloc(100*sizeof(char)), *token, *tmp;
    char saveStr[100];
    while(1){
        fgets(str, 100, stdin);
        *(str + strlen(str)-1) = '\0';
        strcpy(saveStr, str);
        if(!strcmp(str, "quit")) break;

        token = strtok(str, " ");
        if(!strcmp(token, "create")){           // create
            token = strtok(NULL, " ");
            if(!strcmp(token, "bitmap")){
                token = strtok(NULL, " ");
                tmp = strtok(NULL, "\n");
                create_func("bitmap", token, tmp);
            }
            else if(!strcmp(token, "hashtable")){
                token = strtok(NULL, "\n");
                create_func("hashtable", token, "");
            }
            else{
                token = strtok(NULL, "\n");
                create_func("list", token, "");
            }
        }
        else if(!strcmp(token, "dumpdata")){    // dumpdata
            token = strtok(NULL, "\n");
            dump_func(token);
        }
        else if(!strcmp(token, "delete")){      // delete  
            token = strtok(NULL, "\n");
            delete_func(token);
        }
        else{                                   // testlib func
            for(int i=0; i<44; i++){
                if(!strcmp(token, func_array[i])){
                    if(i > 24) list_testlib_func(saveStr, i); 
                    else if (i > 16) hash_testlib_func(saveStr, i);
                    else bitmap_testlib_func(saveStr, i);
                }
            }
        }
    }
    return 0;
}

void create_func(char* type, char* name, char* size){
    if(!strcmp(type, "bitmap")){ 
        strcpy(bArray[bitmap_cnt].name, name);
        bArray[bitmap_cnt++].bitmap_ptr = bitmap_create(atoi(size));
    }
    else if(!strcmp(type, "hashtable")) {
        strcpy(hArray[hash_cnt].name, name);
        hArray[hash_cnt].hash_ptr = (struct hash*)malloc(sizeof(struct hash));
        hash_init(hArray[hash_cnt++].hash_ptr, user_hash_hash_func, user_hash_less_func, aux);
    }
    else {
        strcpy(lArray[list_cnt].name, name);
        lArray[list_cnt].list_ptr = (struct list*)malloc(sizeof(struct list));
        list_init(lArray[list_cnt++].list_ptr);
    }
}

void dump_func(char* name){
    int i, j;
    for(i=0; i<bitmap_cnt; i++){
        if(!strcmp(bArray[i].name, name)) {
            struct bitmap* b = bArray[i].bitmap_ptr;
            for(j = 0; j < (int)bitmap_size(b); j++){
                if(bitmap_test(b, j))
                    printf("1");
                else printf("0");
            }
            printf("\n");
            return;
        }
    }
    for(i=0; i<hash_cnt; i++){
        if(!strcmp(hArray[i].name, name)) {
            struct list_elem *l;
            struct hash_elem *e;
            struct hash* hash = hArray[i].hash_ptr;
            for (j = 0; j < (int)(hash->bucket_cnt); j++) {
                struct list *bucket = &hash->buckets[j];
                for (l = list_begin (bucket); l != list_end (bucket); l = list_next(l)) {
                    e = list_entry(l, struct hash_elem, list_elem);
                    struct hash_item* item = hash_entry(e, struct hash_item, elem);
                    printf("%d ", item->data);
                }
            }
            printf("\n");
            return;
        }
    }
    for(i=0; i<list_cnt; i++){
        if(!strcmp(lArray[i].name, name)) {
            struct list_elem* e;
            struct list* list = lArray[i].list_ptr;
            for(e = list_begin(list); e != list_end(list); e = list_next(e)) {
                struct list_item *item = list_entry(e, struct list_item, elem);
                printf("%d ", item->data);
            }
            printf("\n");
            return;
        }
    }
}

void delete_func(char* name){
    int i;
    for(i=0; i<bitmap_cnt; i++){
        if(!strcmp(bArray[i].name, name)) {
            strcpy(bArray[i].name, "deleted");
            bitmap_destroy(bArray[i].bitmap_ptr);
            return;
        }
    }
    for(i=0; i<hash_cnt; i++){
        if(!strcmp(hArray[i].name, name)) {
            strcpy(hArray[i].name, "deleted");
            struct hash* hash = hArray[i].hash_ptr;
            hash_destroy(hash, hash_destructor);
            return;
        }
    }
    for(i=0; i<list_cnt; i++){
        if(!strcmp(lArray[i].name, name)) {
            strcpy(lArray[i].name, "deleted");
            struct list* list = lArray[i].list_ptr;
            while(!list_empty(list)){
                list_pop_front(list);
            }
            return;
        }
    }
}
