#include "main.h"

unsigned user_hash_hash_func(const struct hash_elem *e, void *aux) {
    struct hash_item* item = hash_entry(e, struct hash_item, elem);
    return hash_int(item->data);
}

bool user_hash_less_func (const struct hash_elem *a, const struct hash_elem *b, void *aux) {
    struct hash_item* item1 = hash_entry(a, struct hash_item, elem);
    struct hash_item* item2 = hash_entry(b, struct hash_item, elem);
    if(item1->data < item2->data) return true;
    else return false;
}

void square (struct hash_elem *e, void *aux) {
    struct hash_item* item = hash_entry(e, struct hash_item, elem);
    item->data = (item->data)*(item->data);
}

void triple (struct hash_elem *e, void *aux) {
    struct hash_item* item = hash_entry(e, struct hash_item, elem);
    item->data = (item->data)*(item->data)*(item->data);
}

void hash_destructor(struct hash_elem *e, void *aux) {
    struct hash_item* item = hash_entry(e, struct hash_item, elem);
    free(item);
}

void hash_testlib_func(char* str, int caseNum){
    struct hash* hash;
    struct hash_item* item;
    char *token = strtok(str, " ");
    token = strtok(NULL, " ");

    for(int i=0; i<hash_cnt; i++){
        if(!strcmp(hArray[i].name, token)) {
            hash = hArray[i].hash_ptr;
        }
    }
    switch(caseNum){
    case HASH_INSERT: {
                          item = malloc(sizeof(struct hash_item));
                          token = strtok(NULL, "\n");
                          item->data = atoi(token);
                          hash_insert(hash, &(item->elem));
                          break;
                      }
    case HASH_APPLY: {
                          token = strtok(NULL, "\n");
                          if(!strcmp(token, "square")) hash_apply(hash, square);
                          else if(!strcmp(token, "triple")) hash_apply(hash, triple);
                          break;
                     }
    case HASH_DELETE: {
                          item = malloc(sizeof(struct hash_item));
                          token = strtok(NULL, "\n");
                          item->data = atoi(token);
                          hash_delete(hash, &(item->elem));
                          break;
                      }
    case HASH_EMPTY: {
                         if(hash_empty(hash)) printf("true\n"); 
                         else printf("false\n");
                         break;
                     }
    case HASH_SIZE: {
                        printf("%zu\n", hash_size(hash)); break;
                    }
    case HASH_CLEAR: {
                         hash_clear(hash, hash_destructor); break;
                     }
    case HASH_FIND: {
                        item = malloc(sizeof(struct hash_item));
                        token = strtok(NULL, "\n");
                        item->data = atoi(token);
                        if(hash_find(hash, &(item->elem))) printf("%d\n", item->data);
                        break;
                    }
    case HASH_REPLACE: {
                          item = malloc(sizeof(struct hash_item));
                          token = strtok(NULL, "\n");
                          item->data = atoi(token);
                          hash_replace(hash, &(item->elem));
                          break;
                       }
    default: return;
    }
}
