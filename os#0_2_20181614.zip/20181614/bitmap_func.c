#include "main.h"

void bitmap_testlib_func(char* str, int caseNum){
    struct bitmap *b;
    char *token = strtok(str, " "),  *token2, *token3;
    token = strtok(NULL, " ");

    for(int i=0; i<bitmap_cnt; i++){
        if(!strcmp(bArray[i].name, token)) {
            b = bArray[i].bitmap_ptr;
            break;
        }
    }
    switch(caseNum){
    case BITMAP_MARK: {
                          token = strtok(NULL, "\n");
                          bitmap_mark(b, atoi(token));
                          break;
                      }
    case BITMAP_ALL: {
                         token = strtok(NULL, " ");
                         token2 = strtok(NULL, "\n");
                         if(bitmap_all(b, atoi(token), atoi(token2))) printf("true\n");
                         else printf("false\n"); 
                         break;
                     }
    case BITMAP_ANY: {
                         token = strtok(NULL, " ");
                         token2 = strtok(NULL, "\n");
                         if(bitmap_any(b, atoi(token), atoi(token2))) printf("true\n");
                         else printf("false\n"); 
                         break;
                     }
    case BITMAP_CONTAINS: {
                              token = strtok(NULL, " ");
                              token2 = strtok(NULL, " ");
                              token3 = strtok(NULL, "\n");
                              if(!strcmp(token3, "true")) {
                                  if(bitmap_contains(b, atoi(token), atoi(token2), true))
                                      printf("true\n");
                                  else printf("false\n"); 
                              }
                              else {
                                  if(bitmap_contains(b, atoi(token), atoi(token2), false))
                                      printf("true\n");
                                  else printf("false\n"); 
                              }
                              break;
                          }
    case BITMAP_COUNT: {
                           token = strtok(NULL, " ");
                           token2 = strtok(NULL, " ");
                           token3 = strtok(NULL, "\n");
                           if(!strcmp(token3, "true"))
                               printf("%zu\n", bitmap_count(b, atoi(token), atoi(token2), true));
                           else printf("%zu\n", bitmap_count(b, atoi(token), atoi(token2), false)); 
                           break;
                       }
    case BITMAP_DUMP: {
                          bitmap_dump(b); break;
                      }
    case BITMAP_EXPAND: {
                            token = strtok(NULL, " ");
                            b = bitmap_expand(b, atoi(token));
                            break;
                        }
    case BITMAP_FLIP: {
                          token = strtok(NULL, "\n");
                          bitmap_flip(b, atoi(token)); break;
                      }
    case BITMAP_NONE: {
                          token = strtok(NULL, " ");
                          token2 = strtok(NULL, "\n");
                          if(bitmap_none(b, atoi(token), atoi(token2))) printf("true\n");
                          else printf("false\n"); 
                          break;
                      }
    case BITMAP_RESET: {
                           token = strtok(NULL, "\n");
                           bitmap_reset(b, atoi(token)); break;
                       }
    case BITMAP_SCAN_AND_FLIP: {
                                   token = strtok(NULL, " ");
                                   token2 = strtok(NULL, " ");
                                   token3 = strtok(NULL, "\n");
                                   if(!strcmp(token3, "true"))
                                       printf("%zu\n", bitmap_scan_and_flip(b, atoi(token), atoi(token2), true)); 
                                   else 
                                       printf("%zu\n", bitmap_scan_and_flip(b, atoi(token), atoi(token2), false)); 
                                   break;
                               }
    case BITMAP_SCAN: {
                          token = strtok(NULL, " ");
                          token2 = strtok(NULL, " ");
                          token3 = strtok(NULL, "\n");
                          if(!strcmp(token3, "true"))
                              printf("%zu\n", bitmap_scan(b, atoi(token), atoi(token2), true)); 
                          else 
                              printf("%zu\n", bitmap_scan(b, atoi(token), atoi(token2), false)); 
                           break;
                      }
    case BITMAP_SET_ALL: {
                             token = strtok(NULL, "\n");
                             if(!strcmp(token, "true")) bitmap_set_all(b, true); 
                             else bitmap_set_all(b, false);
                             break;
                         }
    case BITMAP_SET_MULTIPLE: {
                                  token = strtok(NULL, " ");
                                  token2 = strtok(NULL, " ");
                                  token3 = strtok(NULL, "\n");
                                  if(!strcmp(token3, "true")) 
                                      bitmap_set_multiple(b, atoi(token), atoi(token2), true); 
                                  else
                                      bitmap_set_multiple(b, atoi(token), atoi(token2), false); 
                                  break;
                              }
    case BITMAP_SET: {
                         token = strtok(NULL, " ");
                         token2 = strtok(NULL, "\n");
                         if(!strcmp(token2, "true")) bitmap_set(b, atoi(token), true);
                         else bitmap_set(b, atoi(token), false);
                         break;
                     }
    case BITMAP_SIZE: {
                          printf("%zu\n", bitmap_size(b)); break;
                      }
    case BITMAP_TEST: {
                          token = strtok(NULL, "\n");
                          if(bitmap_test(b, atoi(token))) printf("true\n");
                          else printf("false\n"); 
                          break;
                      }
    default: return;
    }
}
