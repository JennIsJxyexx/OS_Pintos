#include "main.h"

bool user_less_func (const struct list_elem *a, const struct list_elem *b, void *aux) {
    struct list_item* item1 = list_entry(a, struct list_item, elem);
    struct list_item* item2 = list_entry(b, struct list_item, elem);
    if(item1->data < item2->data) return true;
    else return false;
}

void list_testlib_func(char* str, int caseNum){
    void* aux = 0;
    struct list *list, *list2;
    struct list_elem *e1, *e2, *e3;
    struct list_item* item;

    char *token = strtok(str, " "), *token2;
    token = strtok(NULL, " ");

    for(int i=0; i<list_cnt; i++){
        if(!strcmp(lArray[i].name, token)) {
            list = lArray[i].list_ptr;
        }
    }
    switch(caseNum){
    case LIST_PUSH_FRONT: {
                              e1 = malloc(sizeof(struct list_elem));
                              token = strtok(NULL, "\n");
                              list_push_front(list, e1);
                              item = list_entry(e1, struct list_item, elem);
                              item->data = atoi(token);
                              break;
                          }
    case LIST_PUSH_BACK: {
                              e1 = malloc(sizeof(struct list_elem));
                              token = strtok(NULL, "\n");
                              list_push_back(list, e1);
                              item = list_entry(e1, struct list_item, elem);
                              item->data = atoi(token);
                              break;
                         }
    case LIST_FRONT: {
                         e1 = list_front(list); 
                         item = list_entry(e1, struct list_item, elem);
                         printf("%d\n", item->data);
                         break;
                     }
    case LIST_BACK: {
                        e1 = list_back(list);
                        item = list_entry(e1, struct list_item, elem);
                        printf("%d\n", item->data);
                        break;
                    }
    case LIST_POP_BACK: {
                            e1 = list_pop_back(list); 
                            item = list_entry(e1, struct list_item, elem);
                            break;
                        }
    case LIST_POP_FRONT: {
                             e1 = list_pop_front(list); 
                             item = list_entry(e1, struct list_item, elem);
                             break;
                         }
    case LIST_INSERT_ORDERED: {
                                  token = strtok(NULL, "\n");
                                  item = malloc(sizeof(struct list_item));
                                  item->data = atoi(token);
                                  list_insert_ordered(list, &(item->elem), user_less_func, aux);
                                  break;
                              }
    case LIST_INSERT: {
                          token = strtok(NULL, " ");
                          e1 = find_list_elem(list, atoi(token));
                          e2 = malloc(sizeof(struct list_elem));
                          token2 = strtok(NULL, "\n");
                          list_insert(e1, e2);
                          item = list_entry(e2, struct list_item, elem);
                          item->data = atoi(token2);
                          break;
                      }
    case LIST_EMPTY: {
                         if(list_empty(list)) printf("true\n");
                         else printf("false\n");
                         break;
                     }
    case LIST_SIZE: {
                        printf("%zu\n", list_size(list));
                        break;
                    }
    case LIST_MAX: {
                       e1 = list_max(list, user_less_func, aux);
                       item = list_entry(e1, struct list_item, elem);
                       printf("%d\n", item->data);
                       break;
                   }
    case LIST_MIN: {
                       e1 = list_min(list, user_less_func, aux);
                       item = list_entry(e1, struct list_item, elem);
                       printf("%d\n", item->data);
                       break;
                   }
    case LIST_REMOVE: {
                          token = strtok(NULL, "\n");
                          e1 = find_list_elem(list, atoi(token));
                          e2 = list_remove(e1);
                          break;
                      }
    case LIST_REVERSE: {
                           list_reverse(list); break;
                       }
    case LIST_SHUFFLE: {
                           list_shuffle(list); break;
                       }
    case LIST_SORT: {
                        list_sort(list, user_less_func, aux); break;
                    }
    case LIST_SPLICE: {
                          token = strtok(NULL, " ");
                          e1 = find_list_elem(list, atoi(token));
                          token = strtok(NULL, " ");

                          for(int i=0; i<list_cnt; i++){
                              if(!strcmp(lArray[i].name, token)) {
                                  list = lArray[i].list_ptr;
                              }
                          }
                          token = strtok(NULL, " ");
                          e2 = find_list_elem(list, atoi(token));
                          token = strtok(NULL, "\n");
                          e3 = find_list_elem(list, atoi(token));
                          list_splice(e1, e2, e3);
                          break;
                      }
    case LIST_SWAP: {
                        token = strtok(NULL, " ");
                        e1 = find_list_elem(list, atoi(token));
                        token = strtok(NULL, "\n");
                        e2 = find_list_elem(list, atoi(token));
                        list_swap(e1, e2);
                        break;
                    }
    case LIST_UNIQUE: {
                          if((token = strtok(NULL, "\n")) != NULL){
                              for(int i=0; i<list_cnt; i++){
                                  if(!strcmp(lArray[i].name, token)) {
                                      list2 = lArray[i].list_ptr;
                                  }
                              }
                              list_unique(list, list2, user_less_func, aux);
                          }
                          else list_unique(list, NULL, user_less_func, aux);
                          break;
                      }
    default: return;
    }
}

