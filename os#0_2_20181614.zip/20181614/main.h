#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "bitmap.h"
#include "hash.h"
#include "list.h"

///////////////////////////
int bitmap_cnt;
struct bitmap_array
{
    char name[20];
    struct bitmap* bitmap_ptr;
};
struct bitmap_array bArray[11];

///////////////////////////
int hash_cnt;
struct hash_array
{
    char name[20];
    struct hash* hash_ptr;
};
struct hash_array hArray[11];

///////////////////////////
int list_cnt;
struct list_array
{
    char name[20];
    struct list* list_ptr;
};
struct list_array lArray[11];

///////////////////////////

enum testlibFunc {BITMAP_MARK, BITMAP_ALL, BITMAP_ANY, BITMAP_CONTAINS, BITMAP_COUNT, BITMAP_DUMP, BITMAP_EXPAND, BITMAP_FLIP, BITMAP_NONE, BITMAP_RESET, BITMAP_SCAN_AND_FLIP, BITMAP_SCAN, BITMAP_SET_ALL, BITMAP_SET_MULTIPLE, BITMAP_SET, BITMAP_SIZE, BITMAP_TEST, HASH_INSERT, HASH_APPLY, HASH_DELETE, HASH_EMPTY, HASH_SIZE, HASH_CLEAR, HASH_FIND, HASH_REPLACE, LIST_PUSH_FRONT, LIST_PUSH_BACK, LIST_FRONT, LIST_BACK, LIST_POP_BACK, LIST_POP_FRONT, LIST_INSERT_ORDERED, LIST_INSERT, LIST_EMPTY, LIST_SIZE, LIST_MAX, LIST_MIN, LIST_REMOVE, LIST_REVERSE, LIST_SHUFFLE, LIST_SORT, LIST_SPLICE, LIST_SWAP, LIST_UNIQUE};

///////////////////////////

// main.c
void create_func(char* type, char* name, char* size);
void dump_func(char* name);
void delete_func(char* name);

// call testlib func
void bitmap_testlib_func(char* str, int caseNum);
void hash_testlib_func(char* str, int caseNum);
void list_testlib_func(char* str, int caseNum);

// hash func
unsigned user_hash_hash_func(const struct hash_elem *e, void *aux);
bool user_hash_less_func (const struct hash_elem *a, const struct hash_elem *b, void *aux);
void hash_destructor(struct hash_elem *e, void *aux);
